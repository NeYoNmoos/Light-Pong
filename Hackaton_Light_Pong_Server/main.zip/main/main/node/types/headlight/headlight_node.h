#pragma once

void run_as_headlight_node(void);