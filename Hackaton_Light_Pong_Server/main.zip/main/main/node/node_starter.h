#pragma once

void start_node(char* node_type);